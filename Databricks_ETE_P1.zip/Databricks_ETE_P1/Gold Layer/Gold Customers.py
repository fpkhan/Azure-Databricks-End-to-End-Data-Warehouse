# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

init_load_flag = int(dbutils.widgets.get("init_load_flag"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Reading**

# COMMAND ----------

df = spark.sql("select * from databricks_p1_catalogue.silver.customers")

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Removing Duplicates**

# COMMAND ----------

df = df.dropDuplicates(subset=['customer_id'])
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Dividing New and Old Records**

# COMMAND ----------

# MAGIC %md
# MAGIC Separating Old and New Records

# COMMAND ----------

if init_load_flag == 0:
  df_old = spark.sql('''select dim_key, customer_id, create_date, update_date
                      from databricks_p1_catalogue.gold.DimCustomers''')
else:
    df_old = spark.sql('''select 0 dim_key, 0 customer_id, 0 create_date, 0 update_date
                      from databricks_p1_catalogue.silver.customers
                      where 1=0''')


# COMMAND ----------

# MAGIC %md
# MAGIC Reanaming Columns

# COMMAND ----------

df_old = df_old.withColumnRenamed("dim_key", "old_dim_key")\
    .withColumnRenamed("customer_id", "old_customer_id")\
    .withColumnRenamed("create_date", "old_create_date")\
    .withColumnRenamed("update_date", "old_update_date")

# COMMAND ----------

# MAGIC %md
# MAGIC Joining Old and New (new is any rec with value in dimkey) Records to Main Table from Left

# COMMAND ----------

df_join = df.join(df_old,df.customer_id == df_old.old_customer_id,'left')
df_join.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Filtering Old and New Records as distinct dataframes

# COMMAND ----------

df_new = df_join.filter(df_old.old_dim_key.isNull())
df_old = df_join.filter(df_old.old_dim_key.isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC Prepping Old Records Dataframe

# COMMAND ----------

#Dropping unnecessary columns (old_create_date was not dropped as it is a constant after initial loading)
df_old = df_old.drop('old_customer_id','old_update_date')

#The Following updates to the schema is being done to prepare for merging with new dataframe 

#Renaming "old_create_date" to "create_date" with current timestamp
df_old = df_old.withColumnRenamed("old_create_date", "create_date")
df_old = df_old.withColumn('create_date',to_timestamp(col("create_date")))

#Recreating "update_date" to add this to new dataframe with current timestamp
df_old = df_old.withColumn('update_date',current_timestamp())

#Renaming "old_dim_key" to "dim_key"
df_old = df_old.withColumnRenamed("old_dim_key", "dim_key")

# COMMAND ----------

# MAGIC %md
# MAGIC Preparing New Records DataFrame

# COMMAND ----------

#Dropping unnecessary columns (old_create_date was not dropped as it is a constant after initial loading)
df_new = df_new.drop('old_dim_key','old_customer_id','old_update_date', 'old_create_date')

#The Following updates to the schema is being done to prepare for merging with old dataframe 

#Recreating "update_date" and "create_date" to add this to old dataframe with current timestamp
df_new = df_new.withColumn('update_date',current_timestamp())
df_new = df_new.withColumn('create_date',current_timestamp())

# COMMAND ----------

df_new.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Surrogate key**

# COMMAND ----------

# MAGIC %md
# MAGIC Assigning Surrogate Key

# COMMAND ----------

df_new = df_new.withColumn('dim_key', monotonically_increasing_id() + lit(1))
df_new.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Adding Max Surrogate Key

# COMMAND ----------

if init_load_flag == 1:
    max_surrogate_key = 0
else:
    df_maxsur = spark.sql("select max(dim_key) as max_surrogate_key from databricks_p1_catalogue.gold.DimCustomers")
    max_surrogate_key = df_maxsur.collect()[0]['max_surrogate_key']

# COMMAND ----------

df_new = df_new.withColumn('dim_key', col('dim_key')+lit(max_surrogate_key))
df_new.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Union of Old and New Dataframes**

# COMMAND ----------

df_final = df_old.unionByName(df_new)
df_final.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **SCD Type 1 (Delta load and UPSERT)**

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

if init_load_flag == 0:
    dlt_obj = DeltaTable.forPath(spark, "abfss://gold@fidaldatabricksetep1.dfs.core.windows.net/DimCustomers")
    dlt_obj.alias("trg").merge(df_final.alias("src"), "trg.dim_key = src.dim_key")\
        .whenMatchedUpdateAll()\
        .whenNotMatchedInsertAll()\
        .execute()
else:
    df_final.write.mode("overwrite")\
        .format("delta")\
        .option("path", "abfss://gold@fidaldatabricksetep1.dfs.core.windows.net/DimCustomers")\
        .saveAsTable("databricks_p1_catalogue.gold.DimCustomers")\
        

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from databricks_p1_catalogue.gold.dimcustomers

# COMMAND ----------

