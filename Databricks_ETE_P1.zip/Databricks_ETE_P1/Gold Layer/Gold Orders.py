# Databricks notebook source
# MAGIC %md
# MAGIC # **Fact Orders** 

# COMMAND ----------

df = spark.sql("select * from databricks_p1_catalogue.silver.orders")
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Importing the other dataframes from the gold layer**

# COMMAND ----------



# COMMAND ----------

df_dimcus = spark.sql("select dim_key as DimCustomerKey, customer_id as dim_customer_id from databricks_p1_catalogue.gold.dimcustomers")
df_prod = spark.sql("select product_id as DimProductKey, product_id as dim_product_id from databricks_p1_catalogue.gold.dimproducts")


# COMMAND ----------

# MAGIC %md
# MAGIC ### **Fact Dataframe**

# COMMAND ----------

df_fact = df.join(df_dimcus, df.customer_id == df_dimcus.dim_customer_id, how = 'left').join(df_prod, df.product_id == df_prod.dim_product_id, how = 'left')

df_fact = df_fact.drop("dim_customer_id", "dim_product_id", "customer_id", "product_id")
df_fact.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Upsert on Fact Table**

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

if spark.catalog.tableExists("databricks_p1_catalogue.gold.FactOrders"):
    dlt_obj = DeltaTable.forPath(spark, "abfss://gold@fidaldatabricksetep1.dfs.core.windows.net/FactOrders")
    dlt_obj.alias("trg").merge(df_fact.alias("src"), "trg.order_id = src.order_id AND trg.DimCustomerKey = src.DimCustomerKey AND trg.DimProductKey = src.DimProductKey")\
        .whenMatchedUpdateAll()\
        .whenNotMatchedInsertAll()\
        .execute()
else:
    df_fact.write.mode("overwrite")\
        .format("delta")\
        .option("path", "abfss://gold@fidaldatabricksetep1.dfs.core.windows.net/FactOrders")\
        .saveAsTable("databricks_p1_catalogue.gold.FactOrders")\
        

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from databricks_p1_catalogue.gold.factorders

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * from databricks_p1_catalogue.gold.factorders

# COMMAND ----------

