# Databricks notebook source
# MAGIC %md
# MAGIC # **DLT Pipeline** 

# COMMAND ----------

import dlt
from pyspark.sql import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Streaming Table

# COMMAND ----------

#Expectations

my_rules = {
    "rule1" : "product_id IS NOT NULL",
    "rule2" : "product_name IS NOT NULL",
    "rule3" : "category IS NOT NULL",
    "rule4" : "price IS NOT NULL"
}

# COMMAND ----------

@dlt.table()
@dlt.expect_all_or_drop(my_rules)
def DimProducts_Stage():
    df = spark.readStream\
          .format("delta")\
          .option("skipChangeCommits", "true")\
          .table("databricks_p1_catalogue.silver.products")
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Streaming View**

# COMMAND ----------

@dlt.view()
def DimProduct_view():
    df = spark.read.table("Live.DimProducts_Stage")
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ### DimProducts **Creation**

# COMMAND ----------

dlt.create_streaming_table("DimProducts")

# COMMAND ----------

dlt.apply_changes(
    target = "DimProducts",
    source = "Live.DimProducts_Stage",
    keys = ["product_id"],
    sequence_by = "product_id",
    stored_as_scd_type = 2
)

# COMMAND ----------

