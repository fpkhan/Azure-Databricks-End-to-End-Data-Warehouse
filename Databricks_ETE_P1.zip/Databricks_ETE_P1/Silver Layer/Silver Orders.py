# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Reading**

# COMMAND ----------

df = spark.read.format("parquet")\
    .load("abfss://bronze@fidaldatabricksetep1.dfs.core.windows.net/orders")

# COMMAND ----------

df.display()

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df = df.drop("_rescued_data")
df.display()

# COMMAND ----------

df = df.withColumn("year", year(col("order_date")))
df.display()

# COMMAND ----------

df1 = df.withColumn("flag", dense_rank().over(Window.partitionBy("year").orderBy(col("total_amount").desc())))
df1.display()

# COMMAND ----------

df1 = df1.withColumn("rank_flag", rank().over(Window.partitionBy("year").orderBy(col("total_amount").desc())))
df1.display()

# COMMAND ----------

df1 = df1.withColumn("row_number", row_number().over(Window.partitionBy("year").orderBy(col("total_amount").desc())))
df1.display()

# COMMAND ----------



# COMMAND ----------

df = df.withColumn("saleprice", expr("CASE WHEN total_amount > 5000 AND quantity < 4 THEN total_amount * 0.9 ELSE total_amount END"))

df.sort("quantity", ascending = False).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Writing**

# COMMAND ----------

df = df.write.format("delta")\
    .mode("overwrite")\
    .save("abfss://silver@fidaldatabricksetep1.dfs.core.windows.net/orders")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS databricks_p1_catalogue.silver.orders
# MAGIC USING DELTA
# MAGIC LOCATION 'abfss://silver@fidaldatabricksetep1.dfs.core.windows.net/orders'

# COMMAND ----------

