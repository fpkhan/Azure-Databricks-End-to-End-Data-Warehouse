# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Reading**

# COMMAND ----------

df = spark.read.format("parquet")\
    .load("abfss://bronze@fidaldatabricksetep1.dfs.core.windows.net/customers")

# COMMAND ----------

df.display()

# COMMAND ----------

df = df.drop("_rescued_data")

# COMMAND ----------

df = df.withColumn("domains", split(col("email"), "@")[1])
df.display()

# COMMAND ----------

df.groupBy("domains").agg(count("customer_id").alias("total_customers")).orderBy("total_customers", ascending=False).display()

# COMMAND ----------

df_gmail = df.filter(col("domains") == "gmail.com")
display(df_gmail)

df_yahoo = df.filter(col("domains") == "yahoo.com")
display(df_yahoo)

df_hotmail = df.filter(col("domains") == "hotmail.com")
display(df_hotmail)

# COMMAND ----------

df = df.withColumn("fullname", concat(col("first_name"), lit(" "), col("last_name")))
df = df.drop("first_name", "last_name")
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Writing**

# COMMAND ----------

df.write.mode("overwrite").format("delta").save("abfss://silver@fidaldatabricksetep1.dfs.core.windows.net/customers")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS databricks_p1_catalogue.silver.customers
# MAGIC USING DELTA
# MAGIC LOCATION 'abfss://silver@fidaldatabricksetep1.dfs.core.windows.net/customers'
# MAGIC

# COMMAND ----------

