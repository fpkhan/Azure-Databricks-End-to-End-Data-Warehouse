# Databricks notebook source
# MAGIC %md
# MAGIC ### **Data Reading**

# COMMAND ----------

df = spark.read.table("databricks_p1_catalogue.bronze.regions")
df.display()

# COMMAND ----------

df = df.drop("_rescued_data")
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Writing**

# COMMAND ----------

df.write.mode("overwrite").format("delta").save("abfss://silver@fidaldatabricksetep1.dfs.core.windows.net/regions")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS databricks_p1_catalogue.silver.regions
# MAGIC USING DELTA
# MAGIC LOCATION 'abfss://silver@fidaldatabricksetep1.dfs.core.windows.net/regions'

# COMMAND ----------

