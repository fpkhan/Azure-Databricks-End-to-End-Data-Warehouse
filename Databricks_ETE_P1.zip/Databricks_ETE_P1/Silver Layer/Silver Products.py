# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Reading**

# COMMAND ----------

df = spark.read.format("parquet")\
    .load("abfss://bronze@fidaldatabricksetep1.dfs.core.windows.net/products")
df.display()

# COMMAND ----------

df = df.drop("_rescued_data")
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Function**

# COMMAND ----------

df.createOrReplaceTempView("products")


# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE FUNCTION databricks_p1_catalogue.bronze.discount_func(p DOUBLE)
# MAGIC RETURNS DOUBLE
# MAGIC LANGUAGE SQL
# MAGIC RETURN p * 0.90

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT product_id, databricks_p1_catalogue.bronze.discount_func(price) as discounted_price
# MAGIC FROM products

# COMMAND ----------

df = df.withColumn("discounted_price", expr("databricks_p1_catalogue.bronze.discount_func(price)"))
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Writing**

# COMMAND ----------

df.write.format("delta").mode("overwrite").save("abfss://silver@fidaldatabricksetep1.dfs.core.windows.net/products")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS databricks_p1_catalogue.silver.products
# MAGIC USING DELTA
# MAGIC LOCATION 'abfss://silver@fidaldatabricksetep1.dfs.core.windows.net/products'

# COMMAND ----------

